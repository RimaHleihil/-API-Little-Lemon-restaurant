# Little Lemon API using Django Resftul Framework

## URL Endpoints

You can test any of the following endpoints, some of then need authentication.

- restaurant/menu/
- restaurant/menu/{id}
- restaurant/booking/
- auth/
- api-token-auth/
